import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { authenticate } from './AdminLoginService'; // Import the login function from apiService.js
import './AdminLoginForm.css';

const AdminLoginForm = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [role, setRole] = useState('');
  const [showRegistration, setShowRegistration] = useState(false);
  const [registrationData, setRegistrationData] = useState({
    fullname: '',
    contactNo: '',
    email: '',
    password: '',
  });
  const [registrationSuccess, setRegistrationSuccess] = useState(false); // State variable to track registration success
  const [loginSuccess, setLoginSuccess] = useState(false); // State variable to track login success

  const handleLogin = async () => {
    try {
      const token = await authenticate(email, password,role); // Call the login function with username and password
      console.log('Logged in:', token);
      // Handle successful login
      if (token) {
        setLoginSuccess(true); // Set login success to true
      }
    } catch (error) {
      setError('Invalid username or password');
    }
  };

  const handleRegister = () => {
    setShowRegistration(true);
  };

  const handleBackToLogin = () => {
    setShowRegistration(false);
  };

  const handleRegistrationFormChange = (e) => {
    const { name, value } = e.target;
    setRegistrationData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleRegistrationSubmit = async (e) => {
    e.preventDefault();

    if (
      !registrationData.fullname ||
      !registrationData.contactNo ||
      !registrationData.email ||
      !registrationData.password
    ) {
      setError('Please fill in all the fields');
      return;
    }
    
    let url = '';
    if (role === 'user') {
      url = 'http://localhost:8083/register'; // Replace with your User Microservice registration URL
    } else if (role === 'washer') {
      url = 'http://localhost:8084/register'; // Replace with your Washer Microservice registration URL
    }

    try {
      const response = await axios.post(url, registrationData); // Replace 'your-registration-endpoint' with your actual registration API endpoint
      console.log('Registration successful:', response.data);
      setRegistrationSuccess(true); // Set registration success to true
    } catch (error) {
      console.error('Registration error:', error);
      // Handle registration error
    }
  };

  return (
    <div>
       <nav className="navbar">
        <div className="navbar-brand">CarWash</div>
        <ul className="nav-links">
        <li><Link to="/landing">Home</Link></li>
          <li><Link to="/about">AboutUs</Link></li>
          <li><Link to="/contact">ContactUs</Link></li>
        </ul>
      </nav>
    <div className='container'>
    <div className="login-form">
      {showRegistration ? (
        <form className="registration-form" onSubmit={handleRegistrationSubmit}>
          <h2 style={{ marginTop: '0' }}>Registration Form</h2>
          <input
            type="text"
            placeholder="Name"
            name="fullname"
            value={registrationData.fullname}
            onChange={handleRegistrationFormChange}
          />
          <input
            type="text"
            placeholder="Contact"
            name="contactNo"
            value={registrationData.contactNo}
            onChange={handleRegistrationFormChange}
          />
          <input
            type="email"
            placeholder="Email"
            name="email"
            value={registrationData.email}
            onChange={handleRegistrationFormChange}
          />
          <input
            type="password"
            placeholder="Password"
            name="password"
            value={registrationData.password}
            onChange={handleRegistrationFormChange}
          />
           <div className="dropdown" style={{padding:'5px'}}>
              <select
                className="role-dropdown"
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="">-- Select a Role --</option>
                <option value="user">User</option>
                <option value="washer">Washer</option>
              </select>
            </div>
            {error && <p className="error-message">{error}</p>}
          <div className="button-container" style={{ marginTop: '10px' }}>
            <button type="submit" style={{ backgroundColor: '#4caf50' }}>
              Register
            </button>
            <button onClick={handleBackToLogin}>Login</button>
          </div>
        </form>
      ) : (
        <>
          <h2>Login</h2>
          <input
            type="text"
            placeholder="Username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <div className="dropdown" style={{padding:'5px'}}>
              <select
                className="role-dropdown"
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="">-- Select a Role --</option>
                <option value="user">User</option>
                <option value="washer">Washer</option>
                <option value="admin">Admin</option> {/* Added 'admin' option */}
              </select>
            </div>
          {error && <p className="error-message">{error}</p>}
          <div className="button-container" style={{ marginTop: '10px' }}>
            <button onClick={handleLogin}>Login</button>
            <button className="register-button" onClick={handleRegister}>
              Register
            </button>
          </div>
        </>
      )}
      {registrationSuccess && (
        <div className="popup">
          <p>Registration successful!</p>
        </div>
      )}
      {loginSuccess && (
        <div className="popup">
          <p>Login successful!</p>
        </div>
      )}
    </div>
    </div>
    </div>
  );
};

export default AdminLoginForm;

