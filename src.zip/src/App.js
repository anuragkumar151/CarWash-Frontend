import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AdminLoginForm from "./Components/LoginForm";
import Landing from "./Components/Landing";
import AboutUs from "./Components/AboutUs";
import ContactUs from "./Components/ContactUs";
import User from "./Components/User";
import UserBooking from "./Components/UserBooking";
import ViewBooking from "./Components/ViewBooking";
import ProfileUpdate from "./Components/ProfileUpdate";
import TypesOfWash from "./Components/TypesOfWash";
import Washer from "./Components/Washer/Washer";
import BookingsPage from "./Components/Washer/BookingsPage";
import WasherUpdate from "./Components/Washer/WasherUpdate"


function App() {
  
  return (
        <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/landing" element={<Landing />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<ContactUs />} />
            <Route path="/login" element={<AdminLoginForm />} />
            <Route path="/User" element={<User />} />
            <Route path="/Washer" element={<Washer />} />
            <Route path="/UserBooking" element={<UserBooking />} />
            <Route path="/ViewBooking" element={<ViewBooking />} />
            <Route path="/ProfileUpdate" element={<ProfileUpdate />} />
            <Route path="/wash" element={<TypesOfWash/>} />
            <Route path="/BookingsPage" element={<BookingsPage />} />
            <Route path="/WasherUpdate" element={<WasherUpdate />} />
          </Routes>
        </div>
      </Router>
  );
};

export default App;

