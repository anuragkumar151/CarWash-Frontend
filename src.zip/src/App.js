import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AdminLoginForm from "./Components/LoginForm";
import Landing from "./Components/Landing";
import AboutUs from "./Components/AboutUs";
import ContactUs from "./Components/ContactUs";
import User from "./Components/User";
import UserBooking from "./Components/UserBooking";
import ViewBooking from "./Components/ViewBooking";
import BookingUpdate from "./Components/BookingUpdate";
import ProfileUpdate from "./Components/ProfileUpdate";
import TypesOfWash from "./Components/TypesOfWash";
import Washer from "./Components/Washer/Washer";
import BookingsPage from "./Components/Washer/BookingsPage";
import WasherUpdate from "./Components/Washer/WasherUpdate"
import Admin from "./Components/Admin/Admin";
import AdminVBooking from "./Components/Admin/AdminVBooking";


function App() {
  
  return (
        <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/landing" element={<Landing />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<ContactUs />} />
            <Route path="/login" element={<AdminLoginForm />} />
            <Route path="/User" element={<User />} />
            <Route path="/Washer" element={<Washer />} />
            <Route path="/UserBooking" element={<UserBooking />} />
            <Route path="/ViewBooking" element={<ViewBooking />} />
            <Route path="/BookingUpdate" element={<BookingUpdate />} />
            <Route path="/ProfileUpdate" element={<ProfileUpdate />} />
            <Route path="/wash" element={<TypesOfWash/>} />
            <Route path="/BookingsPage" element={<BookingsPage />} />
            <Route path="/WasherUpdate" element={<WasherUpdate />} />
            <Route path="/Admin" element={<Admin />}/>
            <Route path="/AdminVBooking" element={<AdminVBooking />}/> 
          </Routes>
        </div>
      </Router>
  );
};

export default App;

