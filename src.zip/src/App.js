import React from "react";
import './App.css';
import  AdminLoginForm  from './AdminLoginForm';

function App() {
  
  return (
    
    <div className="App">
      <AdminLoginForm />
       </div>
  );
};

export default App;
