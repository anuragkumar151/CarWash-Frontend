import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AdminLoginForm from "./AdminLoginForm";
import Landing from "./Components/Landing";
import AboutUs from "./Components/AboutUs";
import ContactUs from "./Components/ContactUs";
import User from "./Components/User";
import UserBooking from "./Components/UserBooking";

function App() {
  
  return (
        <Router>
        <div className="App">
          {/* <User /> */}
          <UserBooking />
          {/* <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/landing" element={<Landing />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<ContactUs />} />
            <Route path="/login" element={<AdminLoginForm />} />
          </Routes> */}
        </div>
      </Router>
  );
};

export default App;

