// import React, { useState } from "react";
// import axios from "axios";

// export const Register = (props) => {
//     const [email, setEmail] = useState('');
//     const [password, setPass] = useState('');
//     const [fullname, setName] = useState('');
//     const [role, setRole] = useState('');

//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         // Prepare the registration data
//         const registrationData = {
//             fullname: fullname,
//             email: email,
//             password: password,
//         };

//         // Determine the URL based on the selected role
//         let url = '';
//         if (role === 'user') {
//             url = 'http://localhost:8083/register'; // Replace with your User Microservice URL
//         } else if (role === 'washer') {
//             url = 'http://localhost:8084/register'; // Replace with your Washer Microservice URL
//         }

//         // Get the JWT token from wherever it's stored (e.g., localStorage, state, etc.)
//         const token = localStorage.getItem('token'); // Replace with your actual token retrieval logic

//         // Set the request headers with the JWT token
//         const headers = {
//             Authorization: `Bearer ${token}`,
//         };

//         try {
//             // Make the registration request with the JWT token included in the headers
//             const response = await axios.post(url, registrationData, { headers });
//             console.log(response.data); // Handle the response as needed
//         } catch (error) {
//             console.error(error); // Handle any errors that occur during the registration request
//         }
//     };

//     const handleRoleChange = (e) => {
//         setRole(e.target.value);
//     };

//     return (
//         <div className="auth-form-container">
//             <h2>Register</h2>
//             <form className="register-form" onSubmit={handleSubmit}>
//                 <label htmlFor="fullname">Full name</label>
//                 <input value={fullname} name="fullname" onChange={(e) => setName(e.target.value)} id="fullname" placeholder="Full Name" />
//                 <label htmlFor="email">Email</label>
//                 <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="youremail@gmail.com" id="email" name="email" />
//                 <label htmlFor="password">Password</label>
//                 <input value={password} onChange={(e) => setPass(e.target.value)} type="password" placeholder="password" id="password" name="password" />
//                 <div className="container">
//                     <select className="role-dropdown" onChange={handleRoleChange}>
//                         <option value="">-- Select a Role --</option>
//                         <option value="user">User</option>
//                         <option value="washer">Washer</option>
//                     </select>
//                 </div>
//                 <button type="submit">Register</button>
//             </form>
//             <button className="link-btn" onClick={() => props.onFormSwitch('login')}>Already have an account? Login here.</button>
//         </div>
//     );
// };

