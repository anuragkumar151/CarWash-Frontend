// import React, { useState } from "react";
// import axios from "axios";

// export const Login = (props) => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [role, setRole] = useState("");

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Check if any field is empty
//     if (!email || !password || !role) {
//       alert("Please fill in all fields."); // Display an alert
//       return; // Stop further execution
//     }

//     const loginData = {
//       email: email,
//       password: password,
//     };

//     let url = "";
//     if (role === "user") {
//       url = "http://localhost:8083/auth/login"; // Replace with your User Microservice URL
//     } else if (role === "washer") {
//       url = "http://localhost:8084/auth/login"; // Replace with your Washer Microservice URL
//     }

//     // Get the JWT token from wherever it's stored (e.g., localStorage, state, etc.)
//     const token = localStorage.getItem("token"); // Replace with your actual token retrieval logic

//     console.log("Token:", token); // Log the token to the console

//     // Set the request headers with the JWT token
//     const headers = {
//       Authorization: `Bearer ${token}`,
//     };

//     try {
//       // Make the login request with the JWT token included in the headers
//       const response = await axios.post(url, loginData, { headers });
//       console.log("Logged In:", response.data); // Handle the response as needed

//       // If there is no error in the console, redirect to www.google.com
//       if(response){
//       window.location.href = "http://www.google.com";
//       }
//     } catch (error) {
//       console.error(error); // Handle any errors that occur during the login request
//     }
//   };

//   const handleRoleChange = (e) => {
//     setRole(e.target.value);
//   };

//   return (
//     <div className="auth-form-container">
//       <h2>Login</h2>
//       <form className="login-form" onSubmit={handleSubmit}>
//         <label htmlFor="email">Email</label>
//         <input
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//           type="email"
//           placeholder="youremail@gmail.com"
//           id="email"
//           name="email"
//         />
//         <label htmlFor="password">Password</label>
//         <input
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//           type="password"
//           placeholder="********"
//           id="password"
//           name="password"
//         />

//         <div className="container">
//           <select className="role-dropdown" onChange={handleRoleChange}>
//             <option value="">-- Select a Role --</option>
//             <option value="user">User</option>
//             <option value="washer">Washer</option>
//           </select>
//         </div>
//         <button type="submit">Log In</button>
//       </form>
//       <button
//         className="link-btn"
//         onClick={() => props.onFormSwitch("register")}
//       >
//         Don't have an account? Register here.
//       </button>
//     </div>
//   );
// };

