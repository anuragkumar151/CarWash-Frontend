import React from "react";
import { Link } from 'react-router-dom';

const AboutUs = () => {
    const containerStyle = {
       
         display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        backgroundColor: "#D3CFCF",
        width: "100%",
        
      };

  const contentStyle = {
    maxWidth: "600px",
    padding: "20px",
    borderRadius: "8px",
    backgroundColor: "#fff",
    boxShadow: "0 2px 6px rgba(0, 0, 0, 0.1)",
    textAlign: "center",
  };

  return (
    
    <div style={containerStyle}>
        <nav className="navbar">
        <div className="navbar-brand">CarWash</div>
        <ul className="nav-links">
          <li><Link to="/landing">Home</Link></li>
          <li><Link to="/contact">ContactUs</Link></li>
          <li><Link to="/login">Login/Register</Link></li>
        </ul>
      </nav>
      <div style={contentStyle}>
        <h1 style={{ fontSize: "32px", marginBottom: "20px" }}>About Us</h1>
        <p style={{ fontSize: "16px", lineHeight: "1.6" }}>
          We are a car wash company dedicated to providing top-quality car
          cleaning and detailing services. With years of experience and a team
          of skilled professionals, we ensure that your car receives the care
          and attention it deserves. Our mission is to exceed customer
          expectations and deliver exceptional results. Whether you need a
          basic wash or a comprehensive detailing service, we've got you
          covered. Trust us with your car and experience the difference.
        </p>
      </div>
    </div>
  );
};

export default AboutUs;
