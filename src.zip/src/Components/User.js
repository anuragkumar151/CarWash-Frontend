// import React from 'react';
// import { Link } from 'react-router-dom';


// const User = () => {
//   const sidebarStyle = {
//     width: '220px', // Increased width of the sidebar
//     backgroundColor: '#f2f2f2',
//     padding: '20px',
//     marginTop: '5%', 
//   };

//   const menuStyle = {
//     listStyleType: 'none',
//     padding: '0',
//   };

//   const menuItemStyle = {
//     marginBottom: '20px',
//     cursor: 'pointer',
//     transition: 'background-color 0.3s ease', // Added transition for smooth hover effect
//     padding: '8px 60px', // Increased padding to increase the length of navbar
//   };

//   const handleMenuItemHover = (e) => {
//     e.target.style.backgroundColor = '#e0e0e0'; // Change the background color on hover
//   };

//   const handleMenuItemLeave = (e) => {
//     e.target.style.backgroundColor = 'initial'; // Reset the background color on hover leave
//   };

//   return (
//     <div style={sidebarStyle}>
//          <nav className="navbar">
//         <div className="navbar-brand">CarWash</div>
//         <ul className="nav-links">
//           <li><Link to="/landing">Home</Link></li>
//           <li><Link to="/contact">ContactUs</Link></li>
//         </ul>
//       </nav>
//       <ul style={menuStyle}>
//         <li
//           style={menuItemStyle}
//           onMouseEnter={handleMenuItemHover}
//           onMouseLeave={handleMenuItemLeave}
//         >
//           Home
//         </li>
//         <li
//           style={menuItemStyle}
//           onMouseEnter={handleMenuItemHover}
//           onMouseLeave={handleMenuItemLeave}
//         >
//           About
//         </li>
//         <li
//           style={menuItemStyle}
//           onMouseEnter={handleMenuItemHover}
//           onMouseLeave={handleMenuItemLeave}
//         >
//           Services
//         </li>
//         <li
//           style={menuItemStyle}
//           onMouseEnter={handleMenuItemHover}
//           onMouseLeave={handleMenuItemLeave}
//         >
//           Contact
//         </li>
//       </ul>
//     </div>
//   );
// };

// export default User;


import React from 'react';
import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';

const User = () => {
  const sidebarStyle = {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '220px', // Increased width of the sidebar
    backgroundColor: '#F5E5A3',
    padding: '20px',
  };

  const menuStyle = {
    listStyleType: 'none',
    padding: '0',
  };

  const menuItemStyle = {
    marginBottom: '20px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease', // Added transition for smooth hover effect
    padding: '8px 60px', // Increased padding to increase the length of navbar
  };

  const handleMenuItemHover = (e) => {
    e.target.style.backgroundColor = '#e0e0e0'; // Change the background color on hover
  };

  const handleMenuItemLeave = (e) => {
    e.target.style.backgroundColor = 'initial'; // Reset the background color on hover leave
  };

  return (
    <div>
      <div style={sidebarStyle}>
        <nav className="navbar">
          <div className="navbar-brand">CarWash</div>
          <ul className="nav-links">
            <li>
              <Link to="/landing">Home</Link>
            </li>
            <li>
              <Link to="/contact">ContactUs</Link>
            </li>
          </ul>
        </nav>
        <ul style={menuStyle}>
          <li
            style={menuItemStyle}
            onMouseEnter={handleMenuItemHover}
            onMouseLeave={handleMenuItemLeave}
          >
            Home
          </li>
          <li
            style={menuItemStyle}
            onMouseEnter={handleMenuItemHover}
            onMouseLeave={handleMenuItemLeave}
          >
            About
          </li>
          <li
            style={menuItemStyle}
            onMouseEnter={handleMenuItemHover}
            onMouseLeave={handleMenuItemLeave}
          >
            Services
          </li>
          <li
            style={menuItemStyle}
            onMouseEnter={handleMenuItemHover}
            onMouseLeave={handleMenuItemLeave}
          >
            Contact
          </li>
        </ul>
      </div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          padding: '0cm 12cm',
        }}
      >
        <Card style={{ width: '18rem', paddingRight: '1cm', paddingTop: '4cm' }}>
          <Card.Img
            variant="top"
            src="https://cdn.vectorstock.com/i/preview-1x/81/99/angry-upset-young-man-cartoon-vector-39038199.webp"
          />
          <Card.Body style={{ textAlign: 'center' }}>
            <Card.Title>Wash 1</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
            <Button variant="primary">Book</Button>
          </Card.Body>
        </Card>

        <Card style={{ width: '18rem', paddingRight: '1cm', paddingTop: '4cm' }}>
          <Card.Img
            variant="top"
            src="https://cdn.vectorstock.com/i/preview-1x/81/99/angry-upset-young-man-cartoon-vector-39038199.webp"
          />
          <Card.Body style={{ textAlign: 'center' }}>
            <Card.Title>Wash 2</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
            <Button variant="primary">Book</Button>
          </Card.Body>
        </Card>

        <Card style={{ width: '18rem', paddingRight: '1cm', paddingTop: '4cm' }}>
          <Card.Img
            variant="top"
            src="https://cdn.vectorstock.com/i/preview-1x/81/99/angry-upset-young-man-cartoon-vector-39038199.webp"
          />
          <Card.Body style={{ textAlign: 'center' }}>
            <Card.Title>Wash 3</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
            <Button variant="primary">Book</Button>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};

export default User;
