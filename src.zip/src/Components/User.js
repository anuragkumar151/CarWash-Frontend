import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import Navbar from 'react-bootstrap/Navbar';

const User = () => {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredLink, setHoveredLink] = useState(null);

  const cardData = [
    { title: 'Book a Wash', text: 'Experience the ease of cleanliness at your fingertips', buttonText: 'Book', image: 'https://rb.gy/0mk5p', link: '/UserBooking' },
    { title: 'View Booking', text: 'Witness your upcoming experience as you view your booking', buttonText: 'View', image: 'https://rb.gy/khn2y', link: '/ViewBooking' },
    { title: 'Update Booking', text: 'Take charge of your plans with ease as you update your booking', buttonText: 'Update', image: 'https://rb.gy/yuz9x', link: '/BookingUpdate' },
    { title: 'Update Profile', text: 'Unleash your true self by updating your profile', buttonText: 'Update', image: 'https://rb.gy/8wfhg', link: '/ProfileUpdate' },
    { title: 'Give Review', text: 'Share your voice, shape the narrative', buttonText: 'Review', image: 'https://rb.gy/cfht1', link: '/GiveReview' },
  ];

  const handleLinkHover = (index) => {
    setHoveredLink(index);
  };

  const handleBookClick = (link) => {
    // Redirect to the specified link
    window.location.href = link;
  };

  const navbarStyle = {
    backgroundColor: '#000000',
    textDecoration: 'none',
    color: '#FFFFFF',
  };

  const linkStyle = {
    color: hoveredLink === 0 ? '#F1948A' : '#FFFFFF',
  };

  return (
    <div style={{ backgroundColor: '#E2FBF9', minHeight: '100vh', padding: '1rem' }}>
      <Navbar className="navbar" style={navbarStyle}>
        <Navbar.Brand>CarWash</Navbar.Brand>
        <ul className="nav-links">
          <li>
            <Link
              to="/wash"
              style={linkStyle}
              onMouseEnter={() => handleLinkHover(0)}
              onMouseLeave={() => handleLinkHover(null)}
            >
              Types of Wash
            </Link>
          </li>
        </ul>
      </Navbar>
      <div
        className="card-container"
        style={{
          marginTop: '5rem',
          display: '-ms-flexbox',
          justifyContent: 'center',
        }}
      >
        {cardData.map((card, index) => (
          <Card
            key={index}
            className={`card ${hoveredCard === index + 1 ? 'hovered' : ''}`}
            onMouseEnter={() => setHoveredCard(index + 1)}
            onMouseLeave={() => setHoveredCard(null)}
            style={{
              width: '18rem',
              border: '5px solid #ddd',
              backgroundColor: '#F8F8F8',
              boxShadow: hoveredCard === index + 1 ? '0 4px 8px rgba(0, 0, 0, 0.2)' : 'none',
              transform: hoveredCard === index + 1 ? 'scale(1.05)' : 'scale(1)',
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              margin: '2rem',
              display: 'inline-block',
            }}
          >
            <div
              className="card-image"
              style={{
                backgroundImage: `url(${card.image})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                height: '230px',
              }}
            />
            <Card.Body style={{ textAlign: 'center' }}>
              <Card.Title style={{ fontWeight: 'bold' }}>{card.title}</Card.Title>
              <Card.Text>{card.text}</Card.Text>
              <Button variant="primary" onClick={() => handleBookClick(card.link)}>
                {card.buttonText}
              </Button>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default User;
