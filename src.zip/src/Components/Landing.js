import React from 'react';
import { Link } from 'react-router-dom';
import './Landing.css';

const Landing = () => {
  return (
    <div>
      <nav className="navbar">
        <div className="navbar-brand" style={{color: "white"}}>CarWash</div>
        <ul className="nav-links">
          <li><Link to="/about">AboutUs</Link></li>
          <li><Link to="/contact">ContactUs</Link></li>
          <li><Link to="/login">Login/Register</Link></li>
        </ul>
      </nav>
      <div className="background-image"></div>
      <div className="text-box">
        <h1>Welcome to CarWash</h1>
        <p>We offer various car cleaning and detailing services</p>
      </div>
    </div>
  );
};

export default Landing;


