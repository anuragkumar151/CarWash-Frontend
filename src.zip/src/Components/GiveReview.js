import React, { useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import './GiveReview.css';

const GiveReview = () => {
  const [washers, setWashers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [washerName, setWasherName] = useState('');
  const [comments, setComments] = useState('');
  const [rating, setRating] = useState(0);
  const [error, setError] = useState('');

  const handleGetWashers = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:8084/washer/get');
      const data = response.data;
      const fullnames = data.map((washer) => washer.fullname);
      setWashers(fullnames);
      setLoading(false);
    } catch (error) {
      console.log('Error:', error);
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const response = await axios.post('http://localhost:8083/users/ratings/add', {
        washerName,
        comments,
        rating,
      });
      // Handle success or show feedback to the user
      console.log(response.data);
  
      // Show success alert
      Swal.fire('Success', 'Review submitted successfully!', 'success');
    } catch (error) {
      // Handle error or show error message to the user
      console.log('Error:', error);
      setError('An error occurred while submitting the review.');
    }
  
    // Reset form fields
    setWasherName('');
    setComments('');
    setRating(0);
  };
  return (
    <div className="give-review-page">
      <div className="give-review-container">
        <h2>Give Review</h2>
        <button className="get-washers-btn" onClick={handleGetWashers} disabled={loading}>
          {loading ? 'Loading...' : 'Get Washers'}
        </button>

        {washers.length > 0 && (
          <div>
            <h3>Washers</h3>
            <ul>
              {washers.map((washer, index) => (
                <li key={index}>{washer}</li>
              ))}
            </ul>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div>
            <label>Washer Name:</label>
            <select
              value={washerName}
              onChange={(e) => setWasherName(e.target.value)}
            >
              <option value="">Select Washer</option>
              {washers.map((washer, index) => (
                <option key={index} value={washer}>
                  {washer}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label>Comments:</label>
            <textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
            ></textarea>
          </div>
          <div>
            <label>Rating:</label>
            <input
              type="number"
              min="0"
              max="5"
              step="0.5"
              value={rating}
              onChange={(e) => setRating(parseFloat(e.target.value))}
            />
          </div>
          <button type="submit">Submit Review</button>
          {error && <p>{error}</p>}
        </form>
      </div>
    </div>
  );
};

export default GiveReview;
