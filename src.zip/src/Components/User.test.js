import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import User from './User';

describe('User component', () => {
  it('renders the component correctly', () => {
    render(<User />);
    const navbarBrandElement = screen.getByText('CarWash');
    expect(navbarBrandElement).toBeInTheDocument();
  });

  it('displays the types of wash links', () => {
    render(<User />);
    const washLinkElement = screen.getByText('Types of Wash');
    expect(washLinkElement).toBeInTheDocument();
  });

  it('redirects to the specified link on button click', () => {
    render(<User />);
    const bookButtonElement = screen.getByText('Book');
    userEvent.click(bookButtonElement);
    expect(window.location.href).toBe('/UserBooking');
  });
});
