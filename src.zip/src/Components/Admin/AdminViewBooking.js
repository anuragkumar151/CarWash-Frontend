import React, { useState, useEffect } from 'react';
import axios from 'axios';
import swal from 'sweetalert';

const BookingsPage = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await axios.get('http://localhost:8082/booking/all');
      setBookings(response.data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    }
  };

  const deleteBooking = (orderId) => {
    swal({
      title: 'Are you sure?',
      text: 'Once deleted, this booking cannot be recovered!',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    }).then(async (confirmDelete) => {
      if (confirmDelete) {
        try {
          await axios.delete(`http://localhost:8082/booking/${orderId}`);
          fetchBookings(); // Fetch bookings again after deleting
          swal('Booking deleted successfully!', {
            icon: 'success',
          });
        } catch (error) {
          console.error('Error deleting booking:', error);
        }
      }
    });
  };

  return (
    <div style={styles.root}>
      <div style={styles.container}>
        <h2 style={styles.heading}>Bookings:</h2>
        {bookings.length > 0 ? (
          <ul style={styles.list}>
            {bookings.map((booking) => (
              <li key={booking.orderId} style={styles.bookingItem}>
                {Object.entries(booking).map(([field, value]) => (
                  <div key={field} style={styles.bookingField}>
                    <strong>{capitalizeFirstLetter(field)}:</strong> {value}
                  </div>
                ))}
                <button onClick={() => deleteBooking(booking.orderId)} style={styles.deleteButton}>
                  Delete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No bookings found.</p>
        )}
      </div>
    </div>
  );
};

const capitalizeFirstLetter = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

const styles = {
  root: {
    backgroundColor: '#feebeb',
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container: {
    padding: '20px',
  },
  heading: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '20px',
    textAlign: 'center',
  },
  list: {
    listStyle: 'none',
    padding: '0',
  },
  bookingItem: {
    marginBottom: '20px',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#fff',
    width: '400px',
    textAlign: 'center',
  },
  bookingField: {
    fontSize: '16px',
  },
  deleteButton: {
    marginTop: '10px',
    backgroundColor: '#f44336',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 16px',
    cursor: 'pointer',
  },
};

export default BookingsPage;
