import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import Navbar from 'react-bootstrap/Navbar';

const User = () => {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredLink, setHoveredLink] = useState(null);

    const cardData = [
    { title: 'View Bookings', text: 'Stay organized and in control with a single glance',buttonText: 'View', image: 'https://rb.gy/khn2y', link: '/AdminViewBooking' },
    { title: 'View Users', text: 'Explore and view our diverse user community',buttonText: 'View', image: 'https://rb.gy/q0s17', link: '/ViewUsers' },   
    { title: 'Update Users', text: 'Stay ahead of the curve by updating yourself ',buttonText: 'Update', image: 'https://rb.gy/8wfhg', link: '/ProfileUpdate' },
    { title: 'View Washers', text: ' View the skilled washers shaping the future' ,buttonText: 'View', image: 'https://rb.gy/ewyz1', link: '/ViewWashers' },
    { title: 'Update Washer', text: 'Elevate your skills by updating yourself',buttonText: 'Update', image: 'https://rb.gy/k94gh', link: '/WasherUpdate' },
    { title: 'View Ratings', text: 'Uncover valuable insights and make informed decisions ',buttonText: 'View', image: 'https://rb.gy/soqwd', link: '/ViewRating' },
  ];

  const handleLinkHover = (index) => {
    setHoveredLink(index);
  };

  const handleBookClick = (link) => {
    // Redirect to the specified link
    window.location.href = link;
  };

  const navbarStyle = {
    backgroundColor: '#000000',
    textDecoration: 'none',
    color: '#FFFFFF',
  };

  const linkStyle = {
    color: hoveredLink === 0 ? '#F1948A' : '#FFFFFF',
  };

  return (
    <div style={{ backgroundColor: '#E2FBF9', minHeight: '100vh', padding: '1rem' }}>
      <Navbar className="navbar" style={navbarStyle}>
        <Navbar.Brand>CarWash</Navbar.Brand>
        <ul className="nav-links">
          <li>
            <Link
              to="/wash"
              style={linkStyle}
              onMouseEnter={() => handleLinkHover(0)}
              onMouseLeave={() => handleLinkHover(null)}
            >
              Types of Wash
            </Link>
          </li>
        </ul>
      </Navbar>
      <div
        className="card-container"
        style={{
          marginTop: '8rem',
          display: '-ms-flexbox',
          justifyContent: 'center',
        }}
      >
        {cardData.map((card, index) => (
          <Card
            key={index}
            className={`card ${hoveredCard === index + 1 ? 'hovered' : ''}`}
            onMouseEnter={() => setHoveredCard(index + 1)}
            onMouseLeave={() => setHoveredCard(null)}
            style={{
              width: '18rem',
              border: '5px solid #ddd',
              backgroundColor: '#F8F8F8',
              boxShadow: hoveredCard === index + 1 ? '0 4px 8px rgba(0, 0, 0, 0.2)' : 'none',
              transform: hoveredCard === index + 1 ? 'scale(1.05)' : 'scale(1)',
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              margin: '2rem',
              display: 'inline-block',
            }}
          >
            <div
              className="card-image"
              style={{
                backgroundImage: `url(${card.image})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                height: '230px',
              }}
            />
            <Card.Body style={{ textAlign: 'center' }}>
              <Card.Title style={{ fontWeight: 'bold' }}>{card.title}</Card.Title>
              <Card.Text>{card.text}</Card.Text>
              <Button variant="primary" onClick={() => handleBookClick(card.link)}>
                {card.buttonText}
              </Button>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default User;
