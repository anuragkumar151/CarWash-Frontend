import React, { useState, useEffect } from 'react';
import axios from 'axios';
import swal from 'sweetalert';
import './ViewUsers.css';

const ViewUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    getAllUsers();
  }, []);

  const getAllUsers = async () => {
    try {
      const response = await axios.get('http://localhost:8083/users/all');
      const data = response.data;
      setUsers(data);
    } catch (error) {
      console.log('Error:', error);
    }
  };

  const deleteUser = async (userId) => {
    try {
      swal({
        title: 'Are you sure?',
        text: 'Once deleted, this user cannot be recovered!',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      }).then(async (confirmDelete) => {
        if (confirmDelete) {
          await axios.delete(`http://localhost:8083/users/${userId}`);
          getAllUsers(); // Fetch users again after deleting
          swal('User deleted successfully!', {
            icon: 'success',
          });
        }
      });
    } catch (error) {
      console.log('Error deleting user:', error);
    }
  };

  return (
    <div className="container">
      <h2 className="title">All Users</h2>
      <ul className="user-list">
        {users.map((user) => (
          <li key={user.userId} className="user-item">
            <div className="user-info">
              <div className="user-field">
                <span className="field-name">UserID:</span>
                <span className="field-value">{user.userId}</span>
              </div>
              <div className="user-field">
                <span className="field-name">Full Name:</span>
                <span className="field-value">{user.fullname}</span>
              </div>
              <div className="user-field">
                <span className="field-name">Contact No:</span>
                <span className="field-value">{user.contactNo}</span>
              </div>
              <div className="user-field">
                <span className="field-name">Email:</span>
                <span className="field-value">{user.email}</span>
              </div>
            </div>
            <button className="delete-button" onClick={() => deleteUser(user.userId)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ViewUsers;
