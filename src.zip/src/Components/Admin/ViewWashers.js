import React, { useState, useEffect } from 'react';
import axios from 'axios';
import swal from 'sweetalert';
import './ViewWashers.css';

const ViewWashers = () => {
  const [washers, setWashers] = useState([]);

  useEffect(() => {
    getAllWashers();
  }, []);

  const getAllWashers = async () => {
    try {
      const response = await axios.get('http://localhost:8084/washer/get');
      const data = response.data;
      setWashers(data);
    } catch (error) {
      console.log('Error:', error);
    }
  };

  const deleteWasher = async (wid) => {
    try {
      swal({
        title: 'Are you sure?',
        text: 'Once deleted, this washer cannot be recovered!',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      }).then(async (confirmDelete) => {
        if (confirmDelete) {
          await axios.delete(`http://localhost:8084/washer/${wid}`);
          getAllWashers(); // Fetch washers again after deleting
          swal('Washer deleted successfully!', {
            icon: 'success',
          });
        }
      });
    } catch (error) {
      console.log('Error deleting washer:', error);
    }
  };

  return (
    <div className="container">
      <h2 className="title">All Washers</h2>
      <ul className="washer-list">
        {washers.map((washer) => (
          <li key={washer.wid} className="washer-item">
            <div className="washer-info">
              <div className="washer-field">
                <span className="field-name">WasherID:</span>
                <span className="field-value">{washer.wid}</span>
              </div>
              <div className="washer-field">
                <span className="field-name">Full Name:</span>
                <span className="field-value">{washer.fullname}</span>
              </div>
              <div className="washer-field">
                <span className="field-name">Contact No:</span>
                <span className="field-value">{washer.contactNo}</span>
              </div>
              <div className="washer-field">
                <span className="field-name">Email:</span>
                <span className="field-value">{washer.email}</span>
              </div>
            </div>
            <button className="delete-button" onClick={() => deleteWasher(washer.wid)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ViewWashers;
