import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserProfile = () => {
  const [user, setUser] = useState({
    userId: '',
    fullname: '',
    contactNo: '',
    email: '',
    password: '',
  });

  const [updatedUser, setUpdatedUser] = useState({
    fullname: '',
    contactNo: '',
    password: '',
  });

  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch the user profile data from the API and populate the form
    const fetchUserProfile = async () => {
      try {
        const token = localStorage.getItem('token'); // Get the JWT token from storage
        const config = {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        };
        const response = await axios.get('http://localhost:8083/users/email/Anurag@gmail.com', config); // Replace with your API endpoint
        setUser(response.data);
      } catch (error) {
        console.log(error);
        setError('Error retrieving user profile. Please try again.');
      }
    };

    fetchUserProfile();
  }, []);

  const handleInputChange = (e) => {
    setUpdatedUser({ ...updatedUser, [e.target.name]: e.target.value });
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token'); // Get the JWT token from storage
      const config = {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the request headers
        },
      };
      const response = await axios.put(`http://localhost:8083/users/email/${user.email}`, updatedUser, config); // Replace with your API endpoint
      setUser(response.data);
      setError('');
      // Show success message or perform other actions
    } catch (error) {
      console.log(error);
      setError('Error updating user profile. Please try again.');
    }
  };

  return (
    <div>
      {error && <p>{error}</p>}
      <form onSubmit={handleUpdateProfile}>
        <label htmlFor="fullname">Full Name:</label>
        <input type="text" id="fullname" name="fullname" value={updatedUser.fullname} onChange={handleInputChange} />

        <label htmlFor="contactNo">Contact Number:</label>
        <input type="text" id="contactNo" name="contactNo" value={updatedUser.contactNo} onChange={handleInputChange} />

        <label htmlFor="password">Password:</label>
        <input type="password" id="password" name="password" value={updatedUser.password} onChange={handleInputChange} />

        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default UserProfile;
