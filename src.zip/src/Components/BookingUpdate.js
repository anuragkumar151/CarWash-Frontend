import React, { useState } from "react";
import axios from "axios";

const ProfileUpdate = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [carName, setCarName] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [washPack, setWashPack] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [address, setAddress] = useState("");

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    if (phoneNo.length !== 10) {
      alert("Contact number should have exactly 10 digits.");
      return;
    }

    try {
      const response = await axios.put(`http://localhost:8082/booking/edit/${email}`, {
        name,
        email,
        carName,
        phoneNo,
        washPack,
        date,
        time,
        address,
      });

      const updatedBooking = response.data;
      console.log("Updated booking:", updatedBooking);

      alert("You have successfully edited your booking details.");
    } catch (error) {
      console.error("Error updating booking:", error);
    }
  };

  return (
    <div className="whitesmoke-bg">
      <div className="container">
        <div className="row justify-content-left">
          <div className="col-lg-6">
            <h2>Update Booking</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="carName">Car Name:</label>
                <input
                  type="text"
                  id="carName"
                  value={carName}
                  onChange={(e) => setCarName(e.target.value)}
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="phoneNo">Phone Number:</label>
                <input
                  type="tel"
                  id="phoneNo"
                  value={phoneNo}
                  onChange={(e) => {
                    const formattedNumber = e.target.value.replace(/\D/g, "").slice(0, 10);
                    setPhoneNo(formattedNumber);
                  }}
                  className="form-control"
                  maxLength="10"
                />
              </div>
              <div className="form-group">
                <label htmlFor="washPack">Wash Package:</label>
                <select
                  id="washPack"
                  value={washPack}
                  onChange={(e) => setWashPack(e.target.value)}
                  className="form-control"
                >
                  <option value="">Select a wash package</option>
                  <option value="Package 1">Basic</option>
                  <option value="Package 2">Standard</option>
                  <option value="Package 3">Premium</option>
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="date">Date:</label>
                <input
                  type="date"
                  id="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="time">Time:</label>
                <input
                  type="time"
                  id="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="address">Address:</label>
                <textarea
                  id="address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="form-control"
                ></textarea>
              </div>
              <button type="submit" className="btn btn-primary">
                Update Booking
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileUpdate;
