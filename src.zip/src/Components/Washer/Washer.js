import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { FiHome, FiBell, FiMail, FiGrid } from 'react-icons/fi';

const User = () => {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredLink, setHoveredLink] = useState(null);

  const cardData = [
    { title: 'View all Bookings', text: 'Some quick example text...',buttonText: 'View', image: 'https://cdn.vectorstock.com/i/preview-1x/54/58/booking-calendar-icon-or-reservations-vector-47035458.webp', link: '/BookingsPage' },
    { title: 'v', text: 'Some quick example text...',buttonText: 'v', image: 'https://cdn.vectorstock.com/i/preview-1x/24/94/eye-line-icon-vector-15512494.webp', link: '/ProfileUpdate' },
    { title: 'Update Profile', text: 'Some quick example text...',buttonText: 'Update Profile', image: 'https://cdn.vectorstock.com/i/preview-1x/24/35/account-update-icon-vector-45102435.webp', link: '/WasherUpdate' },
  ];

  const handleLinkHover = (index) => {
    setHoveredLink(index);
  };

  const handleBookClick = (link) => {
    // Redirect to the specified link
    window.location.href = link;
  };

  const SidebarLink = ({ to, icon, text }) => {
    const [hoveredLink, setHoveredLink] = useState(false);
    const handleLinkHover = () => setHoveredLink(!hoveredLink);
    const linkStyle = { textDecoration: 'none', color: hoveredLink ? '#F1948A' : '#000000' };

    return (
      <Link to={to} style={{ ...linkStyle, display: 'flex', alignItems: 'center', marginBottom: '15px' }} onMouseEnter={handleLinkHover} onMouseLeave={handleLinkHover}>
        {icon}
        <span style={{ fontSize: '18px', marginLeft: '20px' }}>{text}</span>
      </Link>
    );
  };

  return (
    <div>
      <nav className="navbar">
        <div className="navbar-brand">CarWash</div>
        <ul className="nav-links">
          <li>
            <Link
              to="/wash"
              style={{ textDecoration: 'none', color: hoveredLink === 0 ? '#F1948A' : '#000000' }}
              onMouseEnter={() => handleLinkHover(0)}
              onMouseLeave={() => handleLinkHover(null)}
            >
              Types of Wash
            </Link>
          </li>
        </ul>
      </nav>
      <div style={{ display: 'flex' }}>
        <div style={{ width: '220px', height: '100%', backgroundColor: '#FDEDEC', paddingTop: '100px', color: '#fff' }}>
          <SidebarLink to="/" icon={<FiHome />} text="Home" />
          <SidebarLink to="/notifications" icon={<FiBell />} text="Notifications" />
          <SidebarLink to="/messages" icon={<FiMail />} text="Messages" />
          <SidebarLink to="/more" icon={<FiGrid />} text="More" />
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', padding: '6rem 2rem 2rem 5cm' }}>
          {cardData.map((card, index) => (
            <Card
              key={index}
              className={`card ${hoveredCard === index + 1 ? 'hovered' : ''}`}
              onMouseEnter={() => setHoveredCard(index + 1)}
              onMouseLeave={() => setHoveredCard(null)}
              style={{
                width: '18rem',
                border: '1px solid #ddd',
                boxShadow: hoveredCard === index + 1 ? '0 4px 8px rgba(0, 0, 0, 0.2)' : 'none',
                transform: hoveredCard === index + 1 ? 'scale(1.05)' : 'scale(1)',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                margin: '1rem',
              }}
            >
              <div
                className="card-image"
                style={{
                  backgroundImage: `url(${card.image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  height: '220px', // Adjust the height as needed
                }}
              />
              <Card.Body style={{ textAlign: 'center'}}>
                <Card.Title style={{fontWeight: 'bold'}}>{card.title}</Card.Title>
                <Card.Text>{card.text}</Card.Text>
                <Button variant="primary" onClick={() => handleBookClick(card.link)}>{card.buttonText}</Button>
              </Card.Body>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default User;

