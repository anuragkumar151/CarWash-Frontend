import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewRating.css';

const ViewRating = () => {
  const [ratings, setRatings] = useState([]);

  useEffect(() => {
    fetchRatings();
  }, []);

  const fetchRatings = async () => {
    try {
      const response = await axios.get('http://localhost:8083/users/ratings'); // Replace with your ratings API endpoint
      setRatings(response.data);
    } catch (error) {
      console.error('Error fetching ratings:', error);
    }
  };

  return (
    <div className="view-rating-container">
      <h2 className="view-rating-heading">Ratings</h2>
      {ratings.length === 0 ? (
        <p>No ratings found.</p>
      ) : (
        <div className="rating-card-container">
          {ratings.map((rating) => (
            <div key={rating.id} className="rating-card">
              <div className="rating-washer">{rating.washerName}</div>
              <div className="rating-details">
                <div className="rating-comments">{rating.comments}</div>
                <div className="rating-value">Rating: {rating.rating}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ViewRating;
