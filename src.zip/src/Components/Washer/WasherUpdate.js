import React, { useState } from 'react';
import axios from 'axios';

const WasherUpdate = () => {
  const [washer, setWasher] = useState({
    email: '',
    fullname: '',
    contactNo: '',
    password: ''
  });

  const handleChange = (e) => {
    setWasher({
      ...washer,
      [e.target.name]: e.target.value
    });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.put(`http://localhost:8082/washer/update/${washer.email}`, washer);
      console.log('Washer details updated:', response.data);
      // Handle success, display success message, or redirect to a different page
    } catch (error) {
      console.error('Error updating washer details:', error);
      // Handle error, display error message, or perform error handling logic
    }
  };

  return (
    <div>
      <h2>Update Washer Details</h2>
      <form onSubmit={handleUpdate}>
        <div>
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={washer.email} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="fullname">Full Name:</label>
          <input type="text" id="fullname" name="fullname" value={washer.fullname} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="contactNo">Contact No:</label>
          <input type="text" id="contactNo" name="contactNo" value={washer.contactNo} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={washer.password} onChange={handleChange} required />
        </div>
        <button type="submit">Update Details</button>
      </form>
    </div>
  );
};

export default WasherUpdate;
