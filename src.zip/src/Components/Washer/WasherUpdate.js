import React, { useState } from 'react';
import axios from 'axios';

const WasherUpdate = () => {
  const [washer, setWasher] = useState({
    wid: '',
    fullname: '',
    email: '',
    contactNo: '',
    password: ''
  });

  const handleChange = (e) => {
    setWasher({
      ...washer,
      [e.target.name]: e.target.value
    });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
  
    try {
      const token = localStorage.getItem('jwtToken'); // Retrieve JWT token from storage
  
      if (token) {
        const config = {
          headers: {
            Authorization: `Bearer ${token}`, // Set the Authorization header with the JWT token
            'Content-Type': 'application/json' // Set the Content-Type header if needed
          }
        };
  
        const response = await axios.put(`http://localhost:8084/washer/update/${washer.wid}`, washer, config);
        console.log('Washer details updated:', response.data);
        // Handle success, display success message, or redirect to a different page
      } else {
        // Handle error: JWT token not found
      }
    } catch (error) {
      console.error('Error updating washer details:', error);
      // Handle error, display error message, or perform error handling logic
    }
  };
  
  return (
    <div>
      <h2>Update Washer Details</h2>
      <form onSubmit={handleUpdate}>
        <div>
          <label htmlFor="wid">Washer ID:</label>
          <input type="text" id="wid" name="wid" value={washer.wid} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="fullname">Full Name:</label>
          <input type="text" id="fullname" name="fullname" value={washer.fullname} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={washer.email} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="contactNo">Contact No:</label>
          <input type="text" id="contactNo" name="contactNo" value={washer.contactNo} onChange={handleChange} required />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={washer.password} onChange={handleChange} required />
        </div>
        <button type="submit">Update Details</button>
      </form>
    </div>
  );
};

export default WasherUpdate;
