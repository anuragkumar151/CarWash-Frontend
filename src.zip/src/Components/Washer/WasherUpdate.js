import React, { useState } from "react";
import axios from "axios";

const ProfileUpdate = () => {
  const [fullname, setFirstname] = useState("");
  const [email, setEmail] = useState("");
  const [contactNo, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.put(`http://localhost:8084/washer/update/${email}`, {
        fullname,
        email,
        contactNo,
        password,
      });

      const updatedUser = response.data;
      console.log("Updated user:", updatedUser);

      alert("You have successfully edited your details.");
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  return (
    <div className="whitesmoke-bg">
      <div className="container">
        <div className="row justify-content-left">
          <div className="col-lg-6">
            <h2>Update Washer</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="fullname">Full Name:</label>
                <input
                  type="text"
                  id="fullname"
                  value={fullname}
                  onChange={(e) => setFirstname(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="contactNo">Phone Number:</label>
                <input
                  type="contactNo"
                  id="contactNo"
                  value={contactNo}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Update User
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileUpdate;
