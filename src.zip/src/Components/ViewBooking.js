// import React, { useState } from 'react';
// import axios from 'axios';
// import Card from 'react-bootstrap/Card';
// import Button from 'react-bootstrap/Button';

// const ViewBooking = () => {
//   const [email, setEmail] = useState('');
//   const [bookings, setBookings] = useState([]);
//   const [loading, setLoading] = useState(false);

//   const handleEmailChange = (e) => {
//     setEmail(e.target.value);
//   };

//   const handleViewBookings = async () => {
//     try {
//       setLoading(true);
//       // Make an API call to retrieve the user's bookings based on the provided email
//       const response = await axios.get(`http://localhost:8082/booking/user=${email}`);
//       setBookings(response.data);
//       setLoading(false);
//     } catch (error) {
//       console.log(error);
//       setLoading(false);
//       // Handle error
//     }
//   };

//   return (
//     <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
//       <Card style={{ width: '400px', padding: '2rem' }}>
//         <h2>View Bookings</h2>
//         <div style={{ marginBottom: '1rem' }}>
//           <label htmlFor="email">Enter your email:</label>
//           <input
//             type="email"
//             id="email"
//             placeholder="Email"
//             value={email}
//             onChange={handleEmailChange}
//             style={{ width: '100%', marginTop: '0.5rem' }}
//           />
//         </div>
//         <Button variant="primary" onClick={handleViewBookings} disabled={!email || loading}>
//           {loading ? 'Loading...' : 'View Bookings'}
//         </Button>
//         {bookings.length > 0 && (
//           <div style={{ marginTop: '1.5rem' }}>
//             <h4>Your Bookings:</h4>
//             {bookings.map((booking) => (
//               <div key={booking.orderId} style={{ marginTop: '1rem', background: '#f2f2f2', padding: '1rem' }}>
//                 <p>
//                   Booking ID: <strong>{booking.orderId}</strong>
//                 </p>
//                 <p>
//                   Service: <strong>{booking.service}</strong>
//                 </p>
//                 <p>
//                   Date: <strong>{booking.date}</strong>
//                 </p>
//               </div>
//             ))}
//           </div>
//         )}
//       </Card>
//     </div>
//   );
// };

// export default ViewBooking;

import React, { useState } from 'react';
import axios from 'axios';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import './ViewBooking.css';

const ViewBooking = () => {
  const [email, setEmail] = useState('');
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
    setError('');
  };

  const handleCancelBooking = async (orderId) => {
    const confirmed = window.confirm('Are you sure you want to delete this booking?');
    if (confirmed) {
      try {
        // Make an API call to delete the booking based on the orderId 
        await axios.delete(`http://localhost:8082/booking/${orderId}`);
        // Remove the canceled booking from the state
        setBookings((prevBookings) => prevBookings.filter((booking) => booking.orderId !== orderId));
      } catch (error) {
        console.log(error);
        // Handle error
      }
    }
  };
  

  const handleViewBookings = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`http://localhost:8082/booking/user/${email}`);
      if (response.data.length === 0) {
        setError('No bookings found for this email.');
      } else {
        setBookings(response.data);
        setError('');
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
      setError('Error retrieving bookings. Please try again.');
    }
  };
  
  return (
    <div className="view-booking-container">
      <h2 className="view-booking-title">View Bookings</h2>
      <div className="view-booking-form">
        <label htmlFor="email" className="view-booking-label">Enter your email:</label>
        <div className="view-booking-input-container">
          <input
            type="email"
            id="email"
            placeholder="Email"
            value={email}
            onChange={handleEmailChange}
            className="view-booking-input"
          />
          <button onClick={handleViewBookings} disabled={!email || loading} className="view-booking-button">
            {loading ? 'Loading...' : 'View Bookings'}
          </button>
        </div>
        {error && <p className="view-booking-error">{error}</p>}
      </div>
      {bookings.length > 0 && (
        <div className="view-booking-results">
          <h4>Your Bookings:</h4>
          {bookings.map((booking) => (
            <Card key={booking.orderId} className="view-booking-card">
              <Card.Body>
                <Card.Title>Booking ID: {booking.orderId}</Card.Title>
                <Card.Text>Name: {booking.name}</Card.Text>
                <Card.Text>Car Name: {booking.carName}</Card.Text>
                <Card.Text>Date: {booking.date}</Card.Text>
                <Card.Text>Time: {booking.time}</Card.Text>
                <Card.Text>Address: {booking.address}</Card.Text>
                <Button variant="danger" onClick={() => handleCancelBooking(booking.orderId)}>Cancel Booking</Button>
              </Card.Body>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default ViewBooking;

