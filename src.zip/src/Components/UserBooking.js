import React, { useState } from "react";
import axios from "axios";
import './UserBooking.css';
import Swal from "sweetalert2";

function UserBooking() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [carName, setCarName] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [address, setAddress] = useState("");
  const [washPack, setWashPack] = useState("");

  const washPackOptions = [
    { label: "Basic", price: "Rs500" },
    { label: "Standard", price: "Rs1000" },
    { label: "Premium", price: "Rs2000" }
  ];

  const handlePhoneNoChange = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value.length <= 10) {
      setPhoneNo(value);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Create a transaction on the server
    try {
      const response = await axios.get(`http://localhost:8082/booking/createTransaction/${calculateAmount()}`);
      const { orderId } = response.data;

      // Initialize Razorpay
      const razorpayOptions = {
        key: "rzp_test_7aUfDW2fyZTjB4",
        amount: calculateAmount() * 100,
        currency: "INR",
        name: "Car Wash",
        description: "Car Wash Service",
        order_id: orderId,
        handler: handlePaymentSuccess,
        prefill: {
          name,
          email,
          contact: phoneNo
        }
      };

      const rzp = new window.Razorpay(razorpayOptions);
      rzp.open();
    } catch (error) {
      console.log("Error creating transaction:", error);
    }
  };

  const handlePaymentSuccess = async (response) => {
    // Payment success logic
    console.log("Payment successful:", response);

    // Save the booking data in the database
    try {
      const bookingData = {
        name,
        email,
        carName,
        phoneNo,
        date,
        time,
        address,
        washPack
      };

      await axios.post("http://localhost:8082/booking/add", bookingData);

      // Reset the form fields
      setName("");
      setEmail("");
      setCarName("");
      setPhoneNo("");
      setDate("");
      setTime("");
      setAddress("");
      setWashPack("");

      // Redirect to the success page
      Swal.fire({
        icon: "success",
        title: "Thank you for booking!",
        text: "Your booking has been confirmed. 🎉",
        confirmButtonText: "OK",
      });
    } catch (error) {
      console.log("Error saving booking data:", error);
    }
  };

  const calculateAmount = () => {
    // Calculate the amount based on selected wash pack
    switch (washPack) {
      case "Basic":
        return 500;
      case "Standard":
        return 1000;
      case "Premium":
        return 2000;
      default:
        return 0;
    }
  };

  return (
    <div className="booking-container">
      <div className="booking-form">
        <h1 style={{ textAlign: "center" }}>Booking Form</h1>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Name"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="tel"
            placeholder="Phone Number"
            className="form-control"
            value={phoneNo}
            onChange={handlePhoneNoChange}
            required
          />
          <input
            type="text"
            placeholder="Car Name"
            className="form-control"
            value={carName}
            onChange={(e) => setCarName(e.target.value)}
            required
          />
          <div style={{ textAlign: "center" }}>
            <select
              value={washPack}
              onChange={(e) => setWashPack(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "10px",
                margin: "20px 0",
                fontSize: "16px",
                border: "none",
                borderRadius: "5px",
                backgroundColor: "#f7f7f7",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                transition: "box-shadow 0.3s ease"
              }}
            >
              <option value="">Select Wash Pack</option>
              {washPackOptions.map((option) => (
                <option key={option.label} value={option.label}>
                  {option.label} ({option.price})
                </option>
              ))}
            </select>
          </div>
          <input
            type="date"
            placeholder="Date"
            className="form-control"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
          <input
            type="time"
            placeholder="Time"
            className="form-control"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Address"
            className="form-control"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
          <button type="submit" style={{ width: "100%", marginTop: "10px" }}>Book</button>
        </form>
      </div>
    </div>
  );
}

export default UserBooking;
