import React, { useState } from "react";
import './UserBooking.css';

function UserBooking() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [carName, setCarName] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const handlePhoneNoChange = (e) => {
    const value = e.target.value.replace(/\D/g, ""); // Remove non-digit characters
    if (value.length <= 10) {
      setPhoneNo(value);
    }
  };

  return (
    <div className="booking-container">
      <div className="booking-form">
        <h1 style={{ textAlign: "center" }}>Booking Form</h1>
        <input
          type="text"
          placeholder="Name"
          className="form-control"
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          className="form-control"
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          placeholder="Car Name"
          className="form-control"
          onChange={(e) => setCarName(e.target.value)}
        />
        <input
          type="tel"
          placeholder="Phone Number"
          className="form-control"
          value={phoneNo}
          onChange={handlePhoneNoChange}
        />
        <input
          type="date"
          placeholder="Date"
          className="form-control"
          onChange={(e) => setDate(e.target.value)}
        />
        <input
          type="time"
          placeholder="Time"
          className="form-control"
          onChange={(e) => setTime(e.target.value)}
        />
        <button type="submit" style={{ width: "100%", marginTop: "10px" }}>Book</button>
      </div>
    </div>
  );
}

export default UserBooking;
