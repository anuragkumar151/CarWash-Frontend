import React, { useState } from "react";
import './UserBooking.css';

function UserBooking() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [carName, setCarName] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [address, setAddress] = useState("");
  const [washPack, setWashPack] = useState("");

  
  // Array of wash pack options with their prices
  const washPackOptions = [
    { label: "Basic", price: "Rs500" },
    { label: "Standard", price: "Rs1000" },
    { label: "Premium", price: "Rs2000" }
  ];

  const handlePhoneNoChange = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value.length <= 10) {
      setPhoneNo(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform any required logic here before resetting the form fields

    setName("");
    setEmail("");
    setCarName("");
    setPhoneNo("");
    setDate("");
    setTime("");
    setAddress("");
    setWashPack("");

    // Redirect to the desired URL
    window.location.href = "http://localhost:4242/";
  };
  return (
    <div className="booking-container">
      <div className="booking-form">
        <h1 style={{ textAlign: "center" }}>Booking Form</h1>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Name"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="tel"
            placeholder="Phone Number"
            className="form-control"
            value={phoneNo}
            onChange={handlePhoneNoChange}
            required
          />
          <input
            type="text"
            placeholder="Car Name"
            className="form-control"
            value={carName}
            onChange={(e) => setCarName(e.target.value)}
            required
          />
          <div style={{ textAlign: "center" }}>
            <select
              value={washPack}
              onChange={(e) => setWashPack(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "10px",
                margin: "20px 0",
                fontSize: "16px",
                border: "none",
                borderRadius: "5px",
                backgroundColor: "#f7f7f7",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                transition: "box-shadow 0.3s ease"
              }}
            >
              <option value="">Select Wash Pack</option>
              {washPackOptions.map((option) => (
                <option key={option.label} value={option.label}>
                  {option.label} ({option.price})
                </option>
              ))}
            </select>
          </div>
          <input
            type="date"
            placeholder="Date"
            className="form-control"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
          <input
            type="time"
            placeholder="Time"
            className="form-control"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Address"
            className="form-control"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
          <button type="submit" style={{ width: "100%", marginTop: "10px" }}>Book</button>
        </form>
      </div>
    </div>
  );
}

export default UserBooking;
