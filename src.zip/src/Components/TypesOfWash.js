import React from 'react';
import Card from 'react-bootstrap/Card';
import { FiDroplet, FiWind, FiScissors } from 'react-icons/fi';
import './TypesOfWash.css';

const TypesOfWash = () => {
  const washTypes = [
    {
      title: 'Basic',
      description: 'Clean your car with water and other liquids.',
      icon: <FiDroplet size={50} />,
    },
    {
      title: 'Standard',
      description: 'Clean your car using high-pressure air blowers.',
      icon: <FiWind size={50} />,
    },
    {
      title: 'Premium',
      description: 'Get a complete detailing package for your car.',
      icon: <FiScissors size={50} />,
    },
  ];

  return (
    <div className="types-of-wash-container">
      <h1 className="types-of-wash-heading">Types of Wash</h1>
      <div className="wash-cards-container">
        {washTypes.map((wash, index) => (
          <Card key={index} className="wash-card">
            <div className="wash-icon">{wash.icon}</div>
            <Card.Body>
              <Card.Title>{wash.title}</Card.Title>
              <Card.Text>{wash.description}</Card.Text>
              <button className="wash-button">Book Now</button>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default TypesOfWash;
