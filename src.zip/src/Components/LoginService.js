// import axios from 'axios';

// const authenticate = async (email, password,role) => {
//   try {
//     const config = {
//       headers: {
//         'Content-Type': 'application/json',
//       },
//     };

//     const data = {
//       email,
//       password,
//       role,
//     };

//     let url = '';
//     if (role === 'user') {
//       url = 'http://localhost:8083/auth/login'; // Replace with your User Microservice login URL
//     } else if (role === 'washer') {
//       url = 'http://localhost:8084/auth/login'; // Replace with your Washer Microservice login URL
//     } else if (role === 'admin') {
//       url = 'http://localhost:8081/auth/login'; // Replace with your Admin Microservice login URL
//     }


//     const response = await axios.post(url, data, config);
//     const token = response.data.jwtToken;
//     // Store the token in local storage or session storage
//     localStorage.setItem('token', token);
//     // Set the Authorization header for all future requests
//     axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
//     return token;
//   } catch (error) {
//     throw new Error('Authentication failed');
//   }
// };

// export { authenticate };




import axios from 'axios';

const authenticate = async (email, password,role) => {
  try {
    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const data = {
      email,
      password,
      role,
    };

    let url = '';
    if (role === 'user') {
      url = 'http://localhost:8083/auth/login'; // Replace with your User Microservice login URL
    } else if (role === 'washer') {
      url = 'http://localhost:8084/auth/login'; // Replace with your Washer Microservice login URL
    } else if (role === 'admin') {
      url = 'http://localhost:8081/auth/login'; // Replace with your Admin Microservice login URL
    }


    const response = await axios.post(url, data, config);
    const token = response.data.jwtToken;
    // Store the token in local storage or session storage
    localStorage.setItem('token', token);
    // Set the Authorization header for all future requests
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

    // Redirect to the appropriate page based on the role
    if (role === 'user') {
      window.location.href = '/User';
    } else if (role === 'washer') {
      window.location.href = '/washer/home';
    } else if (role === 'admin') {
      window.location.href = '/admin/home';
    }

    return token;
  } catch (error) {
    throw new Error('Authentication failed');
  }
};

export { authenticate };
