import React from 'react';
import { Link } from 'react-router-dom';

const ContactUs = () => {
  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundColor: "#D3CFCF",
  };

  const contentStyle = {
    maxWidth: '600px',
    padding: '20px',
    borderRadius: '8px',
    backgroundColor: '#fff',
    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc',
  };

  const buttonStyle = {
    width: '100%',
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#4CAF50',
    color: '#fff',
    cursor: 'pointer',
  };

  return (
    <div style={containerStyle}>
       <nav className="navbar">
        <div className="navbar-brand">CarWash</div>
        <ul className="nav-links">
        <li><Link to="/landing">Home</Link></li>
          <li><Link to="/about">AboutUs</Link></li>
          <li><Link to="/login">Login/Register</Link></li>
        </ul>
      </nav>
      <div style={contentStyle}>
        <h1 style={{ fontSize: '32px', marginBottom: '20px' }}>Contact Us</h1>
        <input style={inputStyle} type="text" placeholder="Name" />
        <input style={inputStyle} type="email" placeholder="Email" />
        <textarea style={inputStyle} rows="4" placeholder="Message"></textarea>
        <button style={buttonStyle}>Send Message</button>
      </div>
    </div>
  );
};

export default ContactUs;
