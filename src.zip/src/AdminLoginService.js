import axios from 'axios';

const authenticate = async (email, password) => {
  try {
    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const data = {
      email,
      password,
    };

    const response = await axios.post('http://localhost:8084/auth/login', data, config);
    const token = response.data.jwtToken;
    // Store the token in local storage or session storage
    localStorage.setItem('token', token);
    // Set the Authorization header for all future requests
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    return token;
  } catch (error) {
    throw new Error('Authentication failed');
  }
};

export { authenticate };
